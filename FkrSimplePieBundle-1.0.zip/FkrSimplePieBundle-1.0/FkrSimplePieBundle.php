<?php

namespace Fkr\SimplePieBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class FkrSimplePieBundle extends Bundle
{
}
